package com.wipro.WiproSpringboot;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/home")
    public String showHomePage() {
        return "Welcome to Java Spring Boot Tutorials";
    }
}

	   
//	   @GetMapping("/login")
//	    public ModelAndView showLoginPage(Model model) {
//	        model.addAttribute("message", "Welcome to Java4s Spring Boot Tutorials");
//
//	        return new ModelAndView("login");
//	    }
