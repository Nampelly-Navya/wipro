#!/bin/bash
echo "=== Disk usage ==="
df -h
echo
echo "=== Memory usage ==="
free -m
echo
echo "=== Running Java processes ==="
ps aux | grep java | grep -v grep || echo "No java process running"
