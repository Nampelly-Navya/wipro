# MetroRide CI/CD - Jenkins & Docker

This repository contains CI/CD artifacts and containerization for the MetroRide API.

## Jenkinsfile stages
1. Checkout - pulls code from SCM.
2. Maven Build - runs `mvn -B -DskipTests clean package` and archives the JAR.
3. Archive JAR - lists artifacts and archives them.
4. Docker Build & Push - mocks docker login, builds image, and mocks push to a dummy registry.

## health_check.sh
Run `./health_check.sh` to display disk usage, memory usage, and running Java processes.

## Docker
Build image:
```
docker build -t metroride-api:1.0.0 MetroRideAPI
```
Run container:
```
docker run -p 8080:8080 metroride-api:1.0.0
```

## Docker Compose
Start services:
```
docker-compose up --build
```
