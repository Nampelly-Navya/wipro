package com.metroride.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MetroController {

    @GetMapping("/timing")
    public String getTimings() {
        return "Next metro arrives in 5 mins";
    }
}
