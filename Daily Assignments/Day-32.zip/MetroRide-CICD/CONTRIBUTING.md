Jenkins pipeline is defined in Jenkinsfile.
Docker credentials should not be committed.
Use feature branches and open PRs for CI changes.
