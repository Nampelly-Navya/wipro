# MetroRide Kubernetes Project
Complete Kubernetes & KEDA config.