package com.metroride.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetroRideApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(MetroRideApiApplication.class, args);
    }
}
