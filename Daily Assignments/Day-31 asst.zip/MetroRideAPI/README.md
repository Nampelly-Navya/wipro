# MetroRide API

Simple Spring Boot application (MetroRide) providing a sample endpoint.

## How to run with Maven
- Install JDK and Maven.
- From project root:
  ```
  mvn clean package
  java -jar target/MetroRideAPI-1.0.0.jar
  ```

## How to run with Gradle
- Install JDK and Gradle (or use Gradle wrapper).
  ```
  gradle build
  java -jar build/libs/MetroRideAPI-1.0.0.jar
  ```

## Sample API endpoint
GET `/timing` -> returns "Next metro arrives in 5 mins"
