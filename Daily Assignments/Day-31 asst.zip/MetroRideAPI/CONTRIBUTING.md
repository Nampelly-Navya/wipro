# CONTRIBUTING

## Branch naming
- Use `feature/<short-description>` for new features
- Use `bugfix/<short-description>` for fixes
- Use `hotfix/<short-description>` for urgent fixes

## Commit message format
- Use Conventional style:
  `<type>(<scope>): <short summary>`
  e.g., `feat(controller): add /timing endpoint`
  Types: feat, fix, docs, chore, refactor, test

## Pull Request / Merge Request Guidelines
- Create PR from your feature branch into `main`
- Include summary, testing steps, and linked issue
- At least one reviewer approval is required
- Ensure green build and passing tests
