Current version: 1.0.0
After adding a new feature, increment minor version -> 1.1.0
After bugfixes, increment patch -> 1.0.1
For breaking changes, increment major -> 2.0.0
