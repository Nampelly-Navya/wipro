﻿package com.gl.handler;

import com.gl.model.Person;
import com.gl.repository.PersonRepository;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.UUID;

@Component
public class PersonHandler {

    private final PersonRepository repository;

    public PersonHandler() {
        this.repository = new PersonRepository();
    }

    public Mono<ServerResponse> create(ServerRequest request) {
        Mono<Person> personMono = request.bodyToMono(Person.class)
                .map(p -> {
                    if (p.getId() == null || p.getId().isBlank()) {
                        p.setId(UUID.randomUUID().toString());
                    }
                    return p;
                });

        return personMono.flatMap(person ->
                repository.save(person)
                        .flatMap(saved -> ServerResponse.created(URI.create("/persons/" + saved.getId()))
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(saved))
        );
    }

    public Mono<ServerResponse> getById(ServerRequest request) {
        String id = request.pathVariable("id");
        Mono<Person> personMono = repository.findById(id);

        return personMono.flatMap(person ->
                ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).bodyValue(person)
        ).switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> getAll(ServerRequest request) {
        Flux<Person> all = repository.findAll();
        return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(all, Person.class);
    }

    public Mono<ServerResponse> update(ServerRequest request) {
        String id = request.pathVariable("id");
        Mono<Person> incoming = request.bodyToMono(Person.class);

        return repository.findById(id).flatMap(existing ->
            incoming.flatMap(p -> {
                if (p.getName() != null) existing.setName(p.getName());
                if (p.getAge() != null) existing.setAge(p.getAge());
                if (p.getEmail() != null) existing.setEmail(p.getEmail());
                return repository.save(existing);
            }).flatMap(saved -> ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).bodyValue(saved))
        ).switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> delete(ServerRequest request) {
        String id = request.pathVariable("id");
        return repository.findById(id)
                .flatMap(existing -> repository.delete(id)
                        .then(ServerResponse.noContent().build()))
                .switchIfEmpty(ServerResponse.notFound().build());
    }
}
