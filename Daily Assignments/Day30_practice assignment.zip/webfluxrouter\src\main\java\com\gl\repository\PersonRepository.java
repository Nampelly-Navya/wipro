﻿package com.gl.repository;

import com.gl.model.Person;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PersonRepository {

    private final Map<String, Person> personMap = new ConcurrentHashMap<>();

    public Mono<Person> save(Person person) {
        personMap.put(person.getId(), person);
        return Mono.just(person);
    }

    public Mono<Person> findById(String id) {
        Person p = personMap.get(id);
        return p == null ? Mono.empty() : Mono.just(p);
    }

    public Flux<Person> findAll() {
        return Flux.fromIterable(personMap.values());
    }

    public Mono<Void> delete(String id) {
        personMap.remove(id);
        return Mono.empty();
    }
}
