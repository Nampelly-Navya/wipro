﻿package com.gl.config;

import com.gl.handler.PersonHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.*;

@Configuration
public class RouterConfig {

    @Bean
    public RouterFunction<ServerResponse> router(PersonHandler handler) {
        return RouterFunctions.route()
                .path("/persons", builder -> builder
                        .POST("", RequestPredicates.accept(MediaType.APPLICATION_JSON), handler::create)
                        .GET("", handler::getAll)
                        .GET("/{id}", handler::getById)
                        .PUT("/{id}", RequestPredicates.accept(MediaType.APPLICATION_JSON), handler::update)
                        .DELETE("/{id}", handler::delete)
                ).build();
    }
}
